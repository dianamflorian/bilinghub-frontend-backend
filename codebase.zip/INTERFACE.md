# BillingHub — Deterministic Interface (Exact 50-Item List)

MANDATORY: Every implementation surface MUST be documented with exactly 7 fields.

## Expected Interface

> Contract notes:
> - Path is always an exact repository file path (not a URL). Route URLs are stated in Description.
> - Python types use standard typing; SQLAlchemy Models specify Language-Specific Fields: Bases: db.Model.
> - React components declare explicit Props shapes.
> - List remains exactly 50 rows.

1. Path: backend/models.py | Name: User
- Type: SQLAlchemy Model
- Input: id: int, email: str, stripe_customer_id: str, locked: bool
- Output: Record
- Description: User record; stripe_customer_id MUST be present to attach payment methods and create subscriptions; locked=True forces derived status "Locked".
- Language-Specific Fields: Bases: db.Model

2. Path: backend/models.py | Name: Subscription
- Type: SQLAlchemy Model
- Input: id: int, user_id: int, stripe_sub_id: str, stripe_status: str, cancel_at_period_end: bool, current_period_end: datetime
- Output: Record
- Description: Local mirror of Stripe subscription state used for derived status; must store cancel_at_period_end and current_period_end for terminal cancellation derivation.
- Language-Specific Fields: Bases: db.Model

3. Path: backend/models.py | Name: Plan
- Type: SQLAlchemy Model
- Input: id: int, name: str, amount_cents: int, cycle: str, active: bool
- Output: Record
- Description: Billing plan. amount_cents MUST be > 0. active=False indicates archived.
- Language-Specific Fields: Bases: db.Model

4. Path: backend/models.py | Name: Invoice
- Type: SQLAlchemy Model
- Input: id: int, user_id: int, stripe_invoice_id: str, amount_cents: int, status: str, created_at: datetime
- Output: Record
- Description: Mirrored Stripe invoice metadata for admin and self-service history.
- Language-Specific Fields: Bases: db.Model

5. Path: backend/models.py | Name: GracePeriod
- Type: SQLAlchemy Model
- Input: id: int, subscription_id: int, stripe_invoice_id: str, retry_count: int, started_at: datetime, ends_at: datetime, status: Literal['active','expired','resolved']
- Output: Record
- Description: Dunning episode keyed by (subscription_id, stripe_invoice_id); retry_count is per-episode. Only one status='active' episode should exist per (subscription_id, stripe_invoice_id) (enforced via constraint/index or transactional code).
- Language-Specific Fields: Bases: db.Model

6. Path: backend/models.py | Name: RetryQueue
- Type: SQLAlchemy Model
- Input: id: int, grace_period_id: int, scheduled_at: datetime, status: Literal['queued','processing','succeeded','failed','skipped'], last_error: str | None
- Output: Record
- Description: Durable retry jobs stored in Postgres; must survive restarts. Claimed/processed by worker with row-level locking.
- Language-Specific Fields: Bases: db.Model

7. Path: backend/models.py | Name: WebhookLog
- Type: SQLAlchemy Model
- Input: id: int, stripe_event_id: str, processed: bool, processed_at: datetime | None
- Output: Record
- Description: Webhook idempotency log. stripe_event_id MUST have a DB UNIQUE constraint; handlers must treat duplicates as no-op.
- Language-Specific Fields: Bases: db.Model

8. Path: backend/models.py | Name: AuditLog
- Type: SQLAlchemy Model
- Input: id: int, job_name: str, scheduled_date: date, mismatch_count: int, fixed_count: int, created_at: datetime
- Output: Record
- Description: Reconciliation results. MUST enforce unique constraint on (job_name, scheduled_date) to guarantee idempotency for the daily job.
- Language-Specific Fields: Bases: db.Model

9. Path: backend/logger.py | Name: mask_secrets
- Type: Function
- Input: payload: Any
- Output: Any
- Description: Returns a deep-masked copy suitable for logging. MUST mask values for keys/fields matching: client_secret, JWT/token values, Authorization/auth headers, card, cvv, password.
- Language-Specific Fields: None

10. Path: backend/jobs/runner.py | Name: run_retry_worker
- Type: Job Runner Function
- Input: now: datetime | None = None
- Output: int
- Description: Runs at least hourly. Claims RetryQueue rows due within a ±1 hour window of their scheduled_at and processes them. Must be restart-safe and idempotent per job row state transitions.
- Language-Specific Fields: None

11. Path: backend/jobs/runner.py | Name: run_reconciliation
- Type: Job Runner Function
- Input: scheduled_date: date | None = None
- Output: AuditLog
- Description: Daily reconciliation job intended to run 02:00 UTC. MUST: (1) take a Postgres advisory lock for job_name='daily_reconciliation' and scheduled_date; (2) use idempotency key exactly (job_name, scheduled_date) enforced by AuditLog unique constraint; (3) reconcile local vs Stripe and fix mismatches including cancellation terminal transitions.
- Language-Specific Fields: None

12. Path: backend/jobs/runner.py | Name: claim_job_service
- Type: Service Function
- Input: job_id: int
- Output: bool
- Description: Attempts to claim a single RetryQueue row by primary key using SELECT ... FOR UPDATE (preferably SKIP LOCKED) and transitions it from queued to processing. Returns True iff claim succeeded.
- Language-Specific Fields: None

13. Path: backend/migrations/versions/0001_billing_init.py | Name: billing_init
- Type: Alembic Migration Artifact
- Input: None
- Output: DB schema changes
- Description: Initial billing schema migration. MUST create tables for users, plans, subscriptions, invoices, grace_periods, retry_queue, webhook_logs, audit_logs plus constraints: UNIQUE(webhook_logs.stripe_event_id) and UNIQUE(audit_logs.job_name, audit_logs.scheduled_date).
- Language-Specific Fields: Alembic functions: upgrade(), downgrade()

14. Path: backend/routes/stripe_webhook.py | Name: stripe_ingress
- Type: Flask Route Handler (REST POST)
- Input: body: bytes (request.data), sig: str (Stripe-Signature header)
- Output: Flask Response
- Description: Handles POST /api/stripe/webhook. Validates webhook signature and dispatches to exactly 8 event handlers. Must return 2xx on success; must return 4xx on validation/parse errors (no 500 for signature failures).
- Language-Specific Fields: Decorators: @blueprint.route('/api/stripe/webhook', methods=['POST'])

15. Path: backend/webhooks.py | Name: handle_sub_del
- Type: Handler Function
- Input: data: dict[str, Any]
- Output: str
- Description: Handles customer.subscription.deleted. MUST set local subscription to canceled and enforce Terminal Invariant: expire any active GracePeriod (status='expired') and mark queued retries as skipped.
- Language-Specific Fields: None

16. Path: backend/webhooks.py | Name: handle_pay_fail
- Type: Handler Function
- Input: data: dict[str, Any]
- Output: str
- Description: Handles invoice.payment_failed. Starts/continues an app-managed dunning episode by creating/activating GracePeriod and scheduling retries for day 1/3/7.
- Language-Specific Fields: None

17. Path: backend/webhooks.py | Name: handle_sub_upd
- Type: Handler Function
- Input: data: dict[str, Any]
- Output: str
- Description: Handles customer.subscription.updated. Updates local mirror fields (stripe_status, cancel_at_period_end, current_period_end) used for derived status.
- Language-Specific Fields: None

18. Path: backend/webhooks.py | Name: handle_sub_cre
- Type: Handler Function
- Input: data: dict[str, Any]
- Output: str
- Description: Handles customer.subscription.created. Creates/updates local subscription mirror.
- Language-Specific Fields: None

19. Path: backend/webhooks.py | Name: handle_inv_paid
- Type: Handler Function
- Input: data: dict[str, Any]
- Output: str
- Description: Handles invoice.paid. Marks invoice paid and resolves any active grace episode for the related subscription/invoice.
- Language-Specific Fields: None

20. Path: backend/webhooks.py | Name: handle_inv_fin
- Type: Handler Function
- Input: data: dict[str, Any]
- Output: str
- Description: Handles invoice.finalized. Mirrors invoice metadata locally (amount/status) for history views.
- Language-Specific Fields: None

21. Path: backend/webhooks.py | Name: handle_pi_succ
- Type: Handler Function
- Input: data: dict[str, Any]
- Output: str
- Description: Handles payment_intent.succeeded. Used to complete SCA flows; may trigger subscription state refresh.
- Language-Specific Fields: None

22. Path: backend/webhooks.py | Name: handle_pi_fail
- Type: Handler Function
- Input: data: dict[str, Any]
- Output: str
- Description: Handles payment_intent.payment_failed. Updates local observability/error context and can sustain/extend grace episode behavior (without using Stripe automatic dunning).
- Language-Specific Fields: None

23. Path: backend/services/billing.py | Name: refresh_sync
- Type: Service Function
- Input: sub_id: int
- Output: dict[str, Any]
- Description: Performs synchronous Stripe reads to repair local state. MUST move local state to canceled if Stripe shows canceled OR current_period_end has passed with cancel_at_period_end=True; must also expire active grace and suppress retries when cancellation is detected.
- Language-Specific Fields: None

24. Path: backend/services/billing.py | Name: create_grace
- Type: Service Function
- Input: sub_id: int, invoice_id: str
- Output: GracePeriod
- Description: Creates a GracePeriod episode for (subscription_id, stripe_invoice_id) and schedules day-1 retry.
- Language-Specific Fields: None

25. Path: backend/services/billing.py | Name: lock_user
- Type: Service Function
- Input: user_id: int
- Output: bool
- Description: Sets user.locked=True. Must be invoked after the 3rd failed retry attempt within the same grace episode.
- Language-Specific Fields: None

26. Path: backend/services/billing.py | Name: schedule_retries
- Type: Service Function
- Input: grace_id: int
- Output: list[RetryQueue]
- Description: Enqueues durable retry jobs at offsets day 1, 3, and 7 from GracePeriod.started_at. Worker must treat execution as valid within ±1 hour of scheduled_at.
- Language-Specific Fields: None

27. Path: backend/services/billing.py | Name: execute_retry
- Type: Service Function
- Input: retry_job_id: int
- Output: dict[str, Any]
- Description: Executes one scheduled retry by calling Stripe invoice payment (stripe.Invoice.pay). On failure increments the episode retry_count; after 3 failures locks the user and marks remaining retries as skipped.
- Language-Specific Fields: None

28. Path: backend/services/billing.py | Name: calculate_proration
- Type: Service Function
- Input: sub_id: int, plan_id: int
- Output: dict[str, Any]
- Description: Uses Stripe Upcoming Invoice API to preview prorations for mid-cycle upgrades; returns a deterministic preview payload for UI.
- Language-Specific Fields: None

29. Path: backend/routes/payment_methods.py | Name: attach_pm
- Type: Flask Route Handler (REST POST)
- Input: JSON { pm_id: str }
- Output: JSON { status: 'attached' }
- Description: Handles POST /api/payment-methods/attach. Requires jwt_guard. Attaches a Stripe PaymentMethod to the authenticated user’s Stripe customer and sets it as default for invoicing.
- Language-Specific Fields: Decorators: @blueprint.route('/api/payment-methods/attach', methods=['POST']), @jwt_guard

30. Path: backend/routes/subscriptions.py | Name: create_sub
- Type: Flask Route Handler (REST POST)
- Input: JSON { plan_id: int, pm_id: str }
- Output: JSON { id: str, client_secret: str | null }
- Description: Handles POST /api/subscriptions. Requires jwt_guard. Creates Stripe subscription bound to the provided plan and sets the provided payment method as default. Must support SCA by returning client_secret when subscription/invoice is incomplete. MUST explicitly disable Stripe Smart Retries/automatic dunning (app-managed only).
- Language-Specific Fields: Decorators: @blueprint.route('/api/subscriptions', methods=['POST']), @jwt_guard

31. Path: backend/routes/subscriptions.py | Name: upgrade_sub
- Type: Flask Route Handler (REST POST)
- Input: id: int (path), JSON { plan_id: int }
- Output: JSON { id: str, client_secret: str | null, proration_preview: dict | null }
- Description: Handles POST /api/subscriptions/int:id/up. Requires jwt_guard. Performs mid-cycle upgrade. Must preview proration using Upcoming Invoice API and apply the change; supports SCA if needed.
- Language-Specific Fields: Decorators: @blueprint.route('/api/subscriptions/int:id/up', methods=['POST']), @jwt_guard

32. Path: backend/routes/subscriptions.py | Name: downgrade_sub
- Type: Flask Route Handler (REST POST)
- Input: id: int (path), JSON { plan_id: int }
- Output: JSON { status: 'scheduled' }
- Description: Handles POST /api/subscriptions/int:id/down. Requires jwt_guard. Schedules a downgrade (e.g., via Stripe Subscription Schedules) without immediately changing billing mid-cycle.
- Language-Specific Fields: Decorators: @blueprint.route('/api/subscriptions/int:id/down', methods=['POST']), @jwt_guard

33. Path: backend/routes/subscriptions.py | Name: cancel_sub
- Type: Flask Route Handler (REST POST)
- Input: id: int (path)
- Output: JSON { canceled: true }
- Description: Handles POST /api/subscriptions/int:id/cancel. Requires jwt_guard. Must set Stripe cancel_at_period_end=True. Access remains active until current_period_end. Must suppress retries and ensure cancellation is treated as terminal.
- Language-Specific Fields: Decorators: @blueprint.route('/api/subscriptions/int:id/cancel', methods=['POST']), @jwt_guard

34. Path: backend/routes/admin_plans.py | Name: archive_plan
- Type: Flask Route Handler (REST POST)
- Input: id: int (path)
- Output: JSON { archived: true }
- Description: Handles required POST /api/admin/plans/int:id/archive. Requires admin_guard. Marks plan inactive (archived) locally.
- Language-Specific Fields: Decorators: @blueprint.route('/api/admin/plans/int:id/archive', methods=['POST']), @admin_guard

35. Path: backend/routes/admin_billing.py | Name: admin_list
- Type: Flask Route Handler (REST GET)
- Input: Query status: str | None, plan: int | None, limit: int | None, offset: int | None
- Output: JSON { customers: list[dict], total: int }
- Description: Handles GET /api/admin/billing. Requires admin_guard. Returns admin view including plan, derived status, renewal date, and cancel flag.
- Language-Specific Fields: Decorators: @blueprint.route('/api/admin/billing', methods=['GET']), @admin_guard

36. Path: backend/routes/admin_billing.py | Name: cust_history
- Type: Flask Route Handler (REST GET)
- Input: id: int (path), limit: int | None, offset: int | None
- Output: JSON { items: list[dict], total: int }
- Description: Handles GET /api/admin/customers/int:id/history. Requires admin_guard. Returns invoice history for an arbitrary customer.
- Language-Specific Fields: Decorators: @blueprint.route('/api/admin/customers/int:id/history', methods=['GET']), @admin_guard

37. Path: backend/routes/admin_plans.py | Name: admin_plans
- Type: Flask Route Handler (REST GET/POST)
- Input: GET: none; POST JSON { name: str, amount_cents: int, cycle: str }
- Output: GET JSON list[dict]; POST JSON dict
- Description: Handles GET /api/admin/plans (list) and POST /api/admin/plans (create). Requires admin_guard. Supports plan management requirements.
- Language-Specific Fields: Decorators: @blueprint.route('/api/admin/plans', methods=['GET','POST']), @admin_guard

38. Path: backend/routes/customer_billing.py | Name: my_history
- Type: Flask Route Handler (REST GET)
- Input: Query limit: int | None, offset: int | None
- Output: JSON { items: list[dict], total: int }
- Description: Handles GET /api/customers/me/history. Requires jwt_guard. Authenticated self-service billing history.
- Language-Specific Fields: Decorators: @blueprint.route('/api/customers/me/history', methods=['GET']), @jwt_guard

39. Path: backend/parsing.py | Name: get_derived_status
- Type: Function
- Input: locked: bool, has_active_grace: bool, stripe_status: str, cancel_at_period_end: bool, current_period_end: datetime, now: datetime | None = None
- Output: str
- Description: Implements the mandatory 5-state precedence rules: (1) Locked if locked; (2) Canceled if Stripe canceled OR period_end passed while cancel_at_period_end; (3) Grace Period if active grace; (4) Past Due if Stripe past_due; (5) Active if Stripe active.
- Language-Specific Fields: None

40. Path: backend/auth.py | Name: admin_guard
- Type: Decorator
- Input: fn: Callable[..., Response]
- Output: Callable[..., Response]
- Description: Enforces JWT auth AND admin role. On success sets flask.g.current_user. On failure aborts with 401 (missing/invalid JWT) or 403 (non-admin).
- Language-Specific Fields: Decorators: @wraps

41. Path: backend/auth.py | Name: jwt_guard
- Type: Decorator
- Input: fn: Callable[..., Response]
- Output: Callable[..., Response]
- Description: Enforces JWT-only auth for protected routes. Reads Authorization: Bearer <token>. Sets flask.g.current_user on success; aborts with 401 on failure.
- Language-Specific Fields: Decorators: @wraps

42. Path: backend/error_handler.py | Name: map_stripe_error
- Type: Function
- Input: err: stripe.error.StripeError
- Output: int
- Description: Maps Stripe-originated failures to HTTP status codes strictly among: 429, 502, 503, 400, 500.
- Language-Specific Fields: None

43. Path: backend/app.py | Name: create_app
- Type: Function
- Input: config_overrides: dict[str, Any] | None = None
- Output: Flask
- Description: Flask application factory used by tests and runtime. Must initialize extensions (DB), register all blueprints for routes (admin_plans, admin_billing, subscriptions, payment_methods, customer_billing, stripe_webhook), and register error handlers to ensure deterministic HTTP responses.
- Language-Specific Fields: None

44. Path: frontend/src/api/api.ts | Name: createApiClient
- Type: Function
- Input: baseUrl: string, tokenProvider: () => string | null
- Output: BillingApiClient (object of typed methods returning Promise<T>)
- Description: Creates a typed HTTP client exposing methods for all backend endpoints (attach_pm, create_sub, upgrade_sub, downgrade_sub, cancel_sub, admin_plans, archive_plan, admin_list, cust_history, my_history).
- Language-Specific Fields: Exports: export function createApiClient(...)

45. Path: frontend/src/types/index.ts | Name: types_ts
- Type: Module
- Input: None
- Output: TypeScript interfaces/types
- Description: Mirrors backend models and API DTOs (e.g., Plan, Subscription, Invoice, AuthUser, DerivedStatus). Must align with API responses used by createApiClient.
- Language-Specific Fields: Exports: type/interface

46. Path: frontend/src/components/UpgradeFlow.tsx | Name: UpgradeFlow
- Type: React Component
- Input: props: { plans: Plan[]; onSelectPlan: (planId: number) => void; prorationPreview?: unknown }
- Output: JSX.Element
- Description: UI for selecting an upgrade plan and showing proration preview results.
- Language-Specific Fields: Type: React.FC<Props>

47. Path: frontend/src/components/PaymentStatusBadge.tsx | Name: PaymentStatusBadge
- Type: React Component
- Input: props: { status: DerivedStatus }
- Output: JSX.Element
- Description: Visual indicator for the 5 derived states (Locked/Canceled/Grace Period/Past Due/Active).
- Language-Specific Fields: Type: React.FC<Props>

48. Path: frontend/src/components/StripePaymentForm.tsx | Name: StripePaymentForm
- Type: React Component
- Input: props: { clientSecret: string; onConfirmed?: () => void }
- Output: JSX.Element
- Description: Stripe Elements form used for SCA re-collection when backend returns a client_secret.
- Language-Specific Fields: Type: React.FC<Props>

49. Path: frontend/src/components/Navbar.tsx | Name: Navbar
- Type: React Component
- Input: props: { user: AuthUser | null; derivedStatus?: DerivedStatus }
- Output: JSX.Element
- Description: Primary navigation; shows admin link when user is admin and displays current derived status.
- Language-Specific Fields: Type: React.FC<Props>

50. Path: frontend/src/pages/DashboardPage.tsx | Name: DashboardPage
- Type: React Component
- Input: None
- Output: JSX.Element
- Description: User dashboard that displays subscription details, derived payment status, and billing history; triggers SCA flow when client_secret is present.
- Language-Specific Fields: Type: React.FC
