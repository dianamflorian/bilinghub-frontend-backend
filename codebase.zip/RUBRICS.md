# Evaluation Rubrics (Agentic Rules)
MANDATORY: 30 rubrics capturing the exact 30 most crucial frontend, UI/UX, language-specific, and non-testable architectural boundaries mandated in the prompt.

**Domain**: Fullstack / Frontend UX
**Weights**: All 5 (Mandatory)

1. **Constraint Adherence**: The `Frontend/UI` uses React 18+ and TypeScript exclusively, devoid of any Vue or Angular code artifacts.
2. **Architectural Checks**: The backend DB relies explicitly on Alembic migrations structured strictly at `backend/migrations/versions/0001_billing_init.py`.
3. **Architectural Checks**: The `create_sub` backend logic explicitly defines parameters to prevent stripe smart retries, transferring logic into the app-managed dunning structure.
4. **Qualitative Assessment**: The React frontend exhibits a Professional Freelance visual design standard featuring readable topography and spacing without native browser styling.
5. **Qualitative Assessment**: The Dashboard uses a distinct visual badge (leveraging the requested `PaymentStatusBadge.tsx`) to denote the 5 explicit derived states (Locked / Canceled / Grace Period / Past Due / Active).
6. **Constraint Adherence**: The user can safely browse plan selections using `UpgradeFlow.tsx`, visibly identifying current versus prorated upgrades without network failure. 
7. **Architectural Checks**: The client code handles routing securely through JWT tokens supplied in typical `<Navbar />` mechanisms or local storage abstraction.
8. **Constraint Adherence**: A `createApiClient` function physically surfaces inside `frontend/src/api/api.ts` exposing exact typed methods for REST operations.
9. **Architectural Checks**: `StripePaymentForm.tsx` securely captures SCA tokens from `create_sub` and seamlessly mounts Stripe Elements, waiting strictly on the `client_secret`.
10. **Constraint Adherence**: Both Frontend navigation flows accurately differentiate a User from an Admin (checking JWT layout) and render `Navbar` components accordingly.
11. **Qualitative Assessment**: Error bounding in the React frontend safely displays a Toast notification or clean alert when an API endpoint returns `401` or `403`. 
12. **Qualitative Assessment**: `DashboardPage.tsx` successfully fetches data asynchronously by dispatching calls to `my_history` and `get_user_subscription`.
13. **Architectural Checks**: The `claim_job_service` query structurally passes a strictly mapped SQL query encompassing `FOR UPDATE SKIP LOCKED` inside its Python/SQLAlchemy layout.
14. **Constraint Adherence**: `types_ts` correctly holds the global shapes bridging the Frontend `PaymentStatusBadge` and `Plan` objects without resorting to bare `any` casts.
15. **Architectural Checks**: `run_reconciliation` actively employs a localized Postgres Advisory Lock utilizing a hash mapping on `job_name` string explicitly.
16. **Architectural Checks**: The Webhook system ensures deterministic uniqueness processing referencing `WebhookLog` explicitly avoiding 500 error aborts upon repetition.
17. **Constraint Adherence**: No `Unsplash` references are fetched anywhere in the frontend JSX components, resorting to solid local or legally compliant sources.
18. **Architectural Checks**: The `jwt_guard` and `admin_guard` decorator patterns implement strict `functools.wraps` behavior and map into `flask.g.current_user`.
19. **Qualitative Assessment**: UI forms to submit a new subscription gracefully suspend button states while loading to prevent duplicated form submission.
20. **Constraint Adherence**: The UI restricts "Upgrade" options for `Locked` user interfaces automatically.
21. **Architectural Checks**: The SQL definition specifically implements `Literal['queued','processing','succeeded','failed','skipped']` tracking natively for PostgreSQL ENUM safety.
22. **Architectural Checks**: `admin_guard` enforces a strict extraction resulting in either standard progression or a rigid `abort(403)` HTTP response.
23. **Constraint Adherence**: Types mapped in React interfaces mirror `Plan[]` into rigid TypeScript loops (using `.map()`) displaying cards clearly.
24. **Architectural Checks**: `mask_secrets` physically redacts combinations of tokens explicitly bypassing standard string casting.
25. **Constraint Adherence**: Webhook validation in `stripe_ingress` blocks external calls failing `Sig` validation, immediately emitting `400` logic instead of crashing.
26. **Constraint Adherence**: `refresh_sync` manually sets active grace expiration and skips retries without generating loops if cancellation parameters resolve true.
27. **Qualitative Assessment**: Visual layout explicitly uses Flexbox or CSS Grid constraints to structure the frontend layouts dynamically instead of explicit hard-pixel positioning.
28. **Constraint Adherence**: The test validation explicitly relies on mocked Stripe returns allowing local parsing to maintain 0 server latency responses.
29. **Architectural Checks**: The DB tables maintain cascading relationships verifying deletion limits.
30. **Constraint Adherence**: The whole prompt resolves without fetching any active internet dependencies during the actual runner phase.
